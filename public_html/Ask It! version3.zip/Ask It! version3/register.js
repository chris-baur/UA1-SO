
// Get the modal
var modal = document.getElementById('register');




